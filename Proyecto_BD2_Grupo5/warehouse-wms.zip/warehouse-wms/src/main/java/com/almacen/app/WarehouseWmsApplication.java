package com.almacen.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WarehouseWmsApplication {

	public static void main(String[] args) {
		SpringApplication.run(WarehouseWmsApplication.class, args);
	}

}
